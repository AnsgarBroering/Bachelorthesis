# Vorlage Abschlussarbeiten in der Energieinformatik

## Voraussetzungen
Die Vorlage ist mit TexStudio und der Distribution TexLive getestet worden.

## Informationen
Eine Beschreibung des Templates ist in der mainThesis.pdf zu finden.

## License
This template is licensed under [CC-BY 4.0](https://creativecommons.org/licenses/by/4.0/legalcode) by UOL-DES.

